// 数据库信息，请根据实际情况自行设定
var dbconfig = {
	dbName: 'mysql',
    userName: 'root',
    passward: '',
    host: 'localhost',
    database: 'projectcontrol'
};
module.exports = dbconfig;