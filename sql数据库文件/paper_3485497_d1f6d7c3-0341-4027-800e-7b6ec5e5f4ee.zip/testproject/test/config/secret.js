var secret = 'gamcepmt';//安全密钥：请自行设定，定期更换
module.exports = secret;