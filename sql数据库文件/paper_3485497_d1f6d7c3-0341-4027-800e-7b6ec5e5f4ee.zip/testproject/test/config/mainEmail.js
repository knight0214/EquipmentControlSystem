var mainEmail = {
	 // 请根据自己需要使用的有邮箱自行设定
        host: "smtp.qq.com", // 主机
        secureConnection: true, // 使用 SSL
        port: 465, // SMTP 端口
        auth: {
            user: "249649056@qq.com", // 账号
            pass: "vtulhtblwgfhbhca" // 密码
        }
    };
        module.exports = mainEmail;
